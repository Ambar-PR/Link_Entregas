namespace ProgrammersShopphingCart
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();

            //deshabilitar el boton de Purchase
            btnPurchase.Enabled = false;


            //Metodo de pago seleccionado por defecto
            rbnFullPayment.Checked = true;

        }
        
        private void vhkCSEbook_ChekedChanged (object sender, EventArgs e) 
        {
            if(chkCSEbook.Checked || chkVBSchool.Checked || chkCForPogrammers.Checked)
            {
                btnPurchase.Enabled = true;
            }
            else 
            {
                btnPurchase.Enabled = false;
            }

        }


        private void btnPurchase_Click(object sender, EventArgs e)
        {

            //declarar las variable locales
            string message = "You purchased: \n\r\t";
            int amount = 0;
            string paymentMode = "Your payment mode is: ";


            //validamos cuales libros selecciono el usuario
            if(chkCSEbook.Checked)
            {
                amount += 30;
                message += chkCSEbook.Text + "\n\r\t";
            }

            if(chkVBSchool.Checked)
            {
                amount += 40;
                message += chkVBSchool.Text + "\n\r\t";
            }

            if (chkCForPogrammers.Checked)
            {
                amount += 50;
                message += chkCForPogrammers.Text + "\n\r\t";
            }


            //verificar el modo de pago seleccionado
            if(rbnFullPayment.Checked)
            {
                paymentMode = paymentMode + rbnFullPayment.Text;
            }
            else
            {
                paymentMode = paymentMode + rbnInstallments.Text;
            }


            message += "\n\n\r" + paymentMode + "\n";


            //Total de la orden
            message += "Total due is " + amount.ToString("C");
            //string.Format("{0:C}", amount) --> Lo mismo que el .ToString()

            //Verificar si hubo comentarios
            if(txtComments.TextLength > 0) 
            {
                message += "\n\nYour comments to us are: " + txtComments.Text;
            }

            //mostrar el resumen de la compra
            MessageBox.Show(message);

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Salir de la aplicacion
            Application.Exit();
        }
    }
}
