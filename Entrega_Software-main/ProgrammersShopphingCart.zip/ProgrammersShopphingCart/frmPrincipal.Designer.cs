﻿namespace ProgrammersShopphingCart
{
    partial class frmPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            chkCForPogrammers = new CheckBox();
            chkVBSchool = new CheckBox();
            chkCSEbook = new CheckBox();
            groupBox2 = new GroupBox();
            rbnInstallments = new RadioButton();
            rbnFullPayment = new RadioButton();
            txtComments = new TextBox();
            label2 = new Label();
            btnPurchase = new Button();
            btnExit = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(348, 24);
            label1.Name = "label1";
            label1.Size = new Size(399, 38);
            label1.TabIndex = 0;
            label1.Text = "Programmer's Shopping Cart";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(chkCForPogrammers);
            groupBox1.Controls.Add(chkVBSchool);
            groupBox1.Controls.Add(chkCSEbook);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(22, 99);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(464, 193);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Available Books";
            // 
            // chkCForPogrammers
            // 
            chkCForPogrammers.AutoSize = true;
            chkCForPogrammers.Font = new Font("Segoe UI", 9F);
            chkCForPogrammers.Location = new Point(10, 137);
            chkCForPogrammers.Name = "chkCForPogrammers";
            chkCForPogrammers.Size = new Size(238, 29);
            chkCForPogrammers.TabIndex = 2;
            chkCForPogrammers.Tag = "chkCForPogrammers";
            chkCForPogrammers.Text = "C For Programmers ($50)";
            chkCForPogrammers.UseVisualStyleBackColor = true;
            // 
            // chkVBSchool
            // 
            chkVBSchool.AutoSize = true;
            chkVBSchool.Font = new Font("Segoe UI", 9F);
            chkVBSchool.Location = new Point(10, 91);
            chkVBSchool.Name = "chkVBSchool";
            chkVBSchool.Size = new Size(163, 29);
            chkVBSchool.TabIndex = 1;
            chkVBSchool.Tag = "chkVBSchool";
            chkVBSchool.Text = "VB School ($40)";
            chkVBSchool.UseVisualStyleBackColor = true;
            // 
            // chkCSEbook
            // 
            chkCSEbook.AutoSize = true;
            chkCSEbook.Font = new Font("Segoe UI", 9F);
            chkCSEbook.Location = new Point(12, 46);
            chkCSEbook.Name = "chkCSEbook";
            chkCSEbook.Size = new Size(207, 29);
            chkCSEbook.TabIndex = 0;
            chkCSEbook.Tag = "chkCSEbook";
            chkCSEbook.Text = "C Sharp E-Book ($30)";
            chkCSEbook.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rbnInstallments);
            groupBox2.Controls.Add(rbnFullPayment);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(548, 105);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(425, 183);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Payment Mode";
            // 
            // rbnInstallments
            // 
            rbnInstallments.AutoSize = true;
            rbnInstallments.Font = new Font("Segoe UI", 9F);
            rbnInstallments.Location = new Point(33, 108);
            rbnInstallments.Name = "rbnInstallments";
            rbnInstallments.Size = new Size(132, 29);
            rbnInstallments.TabIndex = 1;
            rbnInstallments.TabStop = true;
            rbnInstallments.Text = "Installments";
            rbnInstallments.UseVisualStyleBackColor = true;
            // 
            // rbnFullPayment
            // 
            rbnFullPayment.AutoSize = true;
            rbnFullPayment.Font = new Font("Segoe UI", 9F);
            rbnFullPayment.Location = new Point(35, 52);
            rbnFullPayment.Name = "rbnFullPayment";
            rbnFullPayment.Size = new Size(137, 29);
            rbnFullPayment.TabIndex = 0;
            rbnFullPayment.TabStop = true;
            rbnFullPayment.Text = "Full Payment";
            rbnFullPayment.UseVisualStyleBackColor = true;
            // 
            // txtComments
            // 
            txtComments.Location = new Point(25, 342);
            txtComments.Multiline = true;
            txtComments.Name = "txtComments";
            txtComments.Size = new Size(464, 171);
            txtComments.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 309);
            label2.Name = "label2";
            label2.Size = new Size(188, 25);
            label2.TabIndex = 4;
            label2.Text = "Your Comments to us:";
            // 
            // btnPurchase
            // 
            btnPurchase.Location = new Point(562, 328);
            btnPurchase.Name = "btnPurchase";
            btnPurchase.Size = new Size(411, 65);
            btnPurchase.TabIndex = 5;
            btnPurchase.Text = "Purchase";
            btnPurchase.UseVisualStyleBackColor = true;
            btnPurchase.Click += btnPurchase_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(560, 417);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(413, 66);
            btnExit.TabIndex = 6;
            btnExit.Tag = "btnExit";
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            // 
            // frmPrincipal
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1029, 547);
            Controls.Add(btnExit);
            Controls.Add(btnPurchase);
            Controls.Add(label2);
            Controls.Add(txtComments);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "frmPrincipal";
            Text = "Programmer's Shopping Cart";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private CheckBox chkCForPogrammers;
        private CheckBox chkVBSchool;
        private CheckBox chkCSEbook;
        private GroupBox groupBox2;
        private RadioButton rbnInstallments;
        private RadioButton rbnFullPayment;
        private TextBox txtComments;
        private Label label2;
        private Button btnPurchase;
        private Button btnExit;
    }
}
