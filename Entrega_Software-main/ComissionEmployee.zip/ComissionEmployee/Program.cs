﻿namespace ComissionEmployee
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ComissionEmployeeClass commissionEmployee = new ComissionEmployeeClass
                (
                "Jorge",
                "Perez",
                "001-0010102-1",
                5000.00M,
                0.05M
                );

            Console.WriteLine(commissionEmployee);
            Console.WriteLine($"Employee Earning {commissionEmployee.Earning()}\n");

            BasePlusCommissionEmployee basePlusCommissionEmployee = new BasePlusCommissionEmployee
                (
                "Adela",
                "Santos",
                "002-02-01204560-4",
                100.00M,
                0.05M
                );

            Console.WriteLine(basePlusCommissionEmployee.ToString);
            Console.WriteLine($"Employee Earning: {basePlusCommissionEmployee.Earning()}\n");
        }
    }
}