﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComissionEmployee
{
    internal class ComissionEmployeeClass
    {
        //Atributos del empleado con propiedades autogeneradas
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Cedula { get; set; }


        //Atributos para las ventas totales y la tasa de comisiones
        private decimal grossSales;
        private decimal commissionRate;

        //Propiedades para controlar los accesos a esos atributos
        public decimal GrossSales
        {
            get { return grossSales; }
            set
            {
                if (value < 0)
                {
                    throw new
                       ArgumentOutOfRangeException(nameof(value),
                       value, $"{nameof(value)} Must be greater than zero"
                       );
                }
                else
                {
                    grossSales = value;
                }

            }
        }

        //Propiedades con accesos get y set
        public decimal CommissionRate
        {
            get { return commissionRate; }
            set
            {
                if (value <= 0 || value >= 1)
                {
                    throw new
                       ArgumentOutOfRangeException(nameof(value),
                       value, $"{nameof(value)} Must be greater than zero"
                       );
                }
                else
                {
                    commissionRate = value;
                }

            }
        }

        //Constructor
        public ComissionEmployeeClass
        (
        string firstName,
        string lastName,
        string cedula,
        decimal grossSales,
        decimal commissionRate
        )

        {
            FirstName = firstName;
            LastName = lastName;
            Cedula = cedula;
            GrossSales = grossSales;
            CommissionRate = commissionRate;
        }

        //Metodo para acalcular las ganancias del vendedor
        public virtual decimal Earning() => CommissionRate * GrossSales; //=> eso es una funcion de flecha: se usa cuando algo devuelve una sola linea de codigo

        //Reescribir una representacion de cadena del metodo ToString
        public override string ToString() =>
            $"Commission Employee: {FirstName} {LastName}\n" +
            $"Id: {Cedula}\n" +
            $"Gross Sales: {GrossSales}\n" +
            $"Commission Rate: {CommissionRate}\n";

    }
}
