﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComissionEmployee
{
    internal class BasePlusCommissionEmployee : ComissionEmployeeClass //Los dos puntos se usa para hereda y luego de donde se va a heredar
    {
        //Atributo Salario base del empleado
        private decimal baseSalary;
        
        //Propiedad para acceder al atributo
        public decimal BaseSalary
        { 
            get { return baseSalary; }
            set
            {
                if (value < 0)
                {
                    throw new
                       ArgumentOutOfRangeException(nameof(value),
                       value, $"{nameof(value)} Must be greater than zero"
                    );

                }
                else 
                {
                    baseSalary = value;
                }
            }
        }

        //Constructor para inicializaar los atributos de la clase que se esta heredando

        public BasePlusCommissionEmployee
          (
            string firstName, string lastName,
            string cedula, decimal grossSales, decimal commissionRate
          )
          :base(firstName, lastName, cedula, grossSales, commissionRate) //Para ir a la clase base y que use el constructor de la clase base
              {
                  BaseSalary = baseSalary; // Definir esa variable en el constructor ya que es unica de este
              }

        //Metodo para calcular las ganancias de ese empleado
        public override decimal Earning() =>
            BaseSalary + (CommissionRate * GrossSales);

        //Version formateada del metodo ToString
        public override string ToString()
        {
            return $"Commission Employee: {FirstName} {LastName}\n" +
            $"Id: {Cedula}\n" +
            $"Gross Sales: {GrossSales}\n" +
            $"Commission Rate: {CommissionRate}\n" +
            $"Base Salary: {BaseSalary}";
        }

    }
}
