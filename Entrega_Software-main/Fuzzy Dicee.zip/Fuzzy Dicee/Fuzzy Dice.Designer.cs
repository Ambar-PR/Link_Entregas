﻿namespace Fuzzy_Dicee
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtOrderNumber = new TextBox();
            label3 = new Label();
            txtCustomerName = new TextBox();
            label4 = new Label();
            txtAdress = new TextBox();
            txtAdress2 = new TextBox();
            txtAdress3 = new TextBox();
            label5 = new Label();
            chkType1 = new CheckBox();
            chkType2 = new CheckBox();
            chkType3 = new CheckBox();
            label6 = new Label();
            QuantityType1 = new TextBox();
            QuantityType2 = new TextBox();
            QuantityType3 = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            btnCalculate = new Button();
            btnExit = new Button();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(250, 27);
            label1.Name = "label1";
            label1.Size = new Size(197, 48);
            label1.TabIndex = 0;
            label1.Text = "Fuzzy Dice";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 126);
            label2.Name = "label2";
            label2.Size = new Size(132, 25);
            label2.TabIndex = 1;
            label2.Text = "Order Number:";
            // 
            // txtOrderNumber
            // 
            txtOrderNumber.Location = new Point(171, 123);
            txtOrderNumber.Name = "txtOrderNumber";
            txtOrderNumber.Size = new Size(150, 31);
            txtOrderNumber.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(21, 212);
            label3.Name = "label3";
            label3.Size = new Size(63, 25);
            label3.TabIndex = 3;
            label3.Text = "Name:";
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(171, 212);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(416, 31);
            txtCustomerName.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(21, 259);
            label4.Name = "label4";
            label4.Size = new Size(70, 25);
            label4.TabIndex = 5;
            label4.Text = "Adress:";
            // 
            // txtAdress
            // 
            txtAdress.Location = new Point(171, 259);
            txtAdress.Name = "txtAdress";
            txtAdress.Size = new Size(416, 31);
            txtAdress.TabIndex = 6;
            // 
            // txtAdress2
            // 
            txtAdress2.Location = new Point(171, 296);
            txtAdress2.Name = "txtAdress2";
            txtAdress2.Size = new Size(416, 31);
            txtAdress2.TabIndex = 7;
            // 
            // txtAdress3
            // 
            txtAdress3.Location = new Point(171, 333);
            txtAdress3.Name = "txtAdress3";
            txtAdress3.Size = new Size(416, 31);
            txtAdress3.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(21, 431);
            label5.Name = "label5";
            label5.Size = new Size(53, 25);
            label5.TabIndex = 9;
            label5.Text = "Type:";
            // 
            // chkType1
            // 
            chkType1.AutoSize = true;
            chkType1.Location = new Point(30, 485);
            chkType1.Name = "chkType1";
            chkType1.Size = new Size(131, 29);
            chkType1.TabIndex = 10;
            chkType1.Text = "White/Black";
            chkType1.UseVisualStyleBackColor = true;
            chkType1.CheckedChanged += chkType1_CheckedChanged;
            // 
            // chkType2
            // 
            chkType2.AutoSize = true;
            chkType2.Location = new Point(30, 530);
            chkType2.Name = "chkType2";
            chkType2.Size = new Size(115, 29);
            chkType2.TabIndex = 11;
            chkType2.Text = "Red/Black";
            chkType2.UseVisualStyleBackColor = true;
            // 
            // chkType3
            // 
            chkType3.AutoSize = true;
            chkType3.Location = new Point(30, 574);
            chkType3.Name = "chkType3";
            chkType3.Size = new Size(118, 29);
            chkType3.TabIndex = 12;
            chkType3.Text = "Blue/Black";
            chkType3.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(199, 431);
            label6.Name = "label6";
            label6.Size = new Size(84, 25);
            label6.TabIndex = 13;
            label6.Text = "Quantity:";
            // 
            // QuantityType1
            // 
            QuantityType1.Location = new Point(199, 485);
            QuantityType1.Name = "QuantityType1";
            QuantityType1.Size = new Size(150, 31);
            QuantityType1.TabIndex = 14;
            QuantityType1.TextAlign = HorizontalAlignment.Right;
            // 
            // QuantityType2
            // 
            QuantityType2.Location = new Point(199, 528);
            QuantityType2.Name = "QuantityType2";
            QuantityType2.Size = new Size(150, 31);
            QuantityType2.TabIndex = 15;
            QuantityType2.TextAlign = HorizontalAlignment.Right;
            // 
            // QuantityType3
            // 
            QuantityType3.Location = new Point(199, 572);
            QuantityType3.Name = "QuantityType3";
            QuantityType3.Size = new Size(150, 31);
            QuantityType3.TabIndex = 16;
            QuantityType3.TextAlign = HorizontalAlignment.Right;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(413, 431);
            label7.Name = "label7";
            label7.Size = new Size(53, 25);
            label7.TabIndex = 17;
            label7.Text = "Price:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(413, 485);
            label8.Name = "label8";
            label8.Size = new Size(56, 25);
            label8.TabIndex = 18;
            label8.Text = "$6.25";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(413, 531);
            label9.Name = "label9";
            label9.Size = new Size(56, 25);
            label9.TabIndex = 19;
            label9.Text = "$5.00";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(413, 574);
            label10.Name = "label10";
            label10.Size = new Size(56, 25);
            label10.TabIndex = 20;
            label10.Text = "$7.50";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(542, 431);
            label11.Name = "label11";
            label11.Size = new Size(61, 25);
            label11.TabIndex = 21;
            label11.Text = "Totals:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(413, 649);
            label12.Name = "label12";
            label12.Size = new Size(84, 25);
            label12.TabIndex = 22;
            label12.Text = "SubTotal:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(413, 715);
            label13.Name = "label13";
            label13.Size = new Size(40, 25);
            label13.TabIndex = 27;
            label13.Text = "Tax:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(413, 755);
            label14.Name = "label14";
            label14.Size = new Size(87, 25);
            label14.TabIndex = 28;
            label14.Text = "Shipping:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(413, 795);
            label15.Name = "label15";
            label15.Size = new Size(94, 25);
            label15.TabIndex = 29;
            label15.Text = "Disscount:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(413, 834);
            label16.Name = "label16";
            label16.Size = new Size(53, 25);
            label16.TabIndex = 30;
            label16.Text = "Total:";
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(58, 665);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(232, 67);
            btnCalculate.TabIndex = 31;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(55, 770);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(232, 67);
            btnExit.TabIndex = 32;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(544, 482);
            label17.Name = "label17";
            label17.Size = new Size(0, 25);
            label17.TabIndex = 33;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(544, 530);
            label18.Name = "label18";
            label18.Size = new Size(0, 25);
            label18.TabIndex = 34;
            label18.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(544, 575);
            label19.Name = "label19";
            label19.Size = new Size(0, 25);
            label19.TabIndex = 35;
            label19.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(544, 649);
            label20.Name = "label20";
            label20.Size = new Size(0, 25);
            label20.TabIndex = 36;
            label20.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(542, 710);
            label21.Name = "label21";
            label21.Size = new Size(0, 25);
            label21.TabIndex = 37;
            label21.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(542, 751);
            label22.Name = "label22";
            label22.Size = new Size(0, 25);
            label22.TabIndex = 38;
            label22.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(542, 792);
            label23.Name = "label23";
            label23.Size = new Size(0, 25);
            label23.TabIndex = 39;
            label23.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(542, 834);
            label24.Name = "label24";
            label24.Size = new Size(0, 25);
            label24.TabIndex = 40;
            label24.TextAlign = ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(939, 897);
            Controls.Add(label24);
            Controls.Add(label23);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(btnExit);
            Controls.Add(btnCalculate);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(QuantityType3);
            Controls.Add(QuantityType2);
            Controls.Add(QuantityType1);
            Controls.Add(label6);
            Controls.Add(chkType3);
            Controls.Add(chkType2);
            Controls.Add(chkType1);
            Controls.Add(label5);
            Controls.Add(txtAdress3);
            Controls.Add(txtAdress2);
            Controls.Add(txtAdress);
            Controls.Add(label4);
            Controls.Add(txtCustomerName);
            Controls.Add(label3);
            Controls.Add(txtOrderNumber);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Fuzzy Dice";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtOrderNumber;
        private Label label3;
        private TextBox txtCustomerName;
        private Label label4;
        private TextBox txtAdress;
        private TextBox txtAdress2;
        private TextBox txtAdress3;
        private Label label5;
        private CheckBox chkType1;
        private CheckBox chkType2;
        private CheckBox chkType3;
        private Label label6;
        private TextBox QuantityType1;
        private TextBox QuantityType2;
        private TextBox QuantityType3;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Button btnCalculate;
        private Button btnExit;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
    }
}
