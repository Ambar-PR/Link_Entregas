namespace Fuzzy_Dicee
{
    public partial class Form1 : Form
    {
        const double price1 = 6.25;
        const double price2 = 5.00;
        const double price3 = 7.50;

        const double tax = 0.05;


        //variables para almacenar las cantidades de los items
        uint quantityType1;
        uint quantityType2;
        uint quantityType3;


        public Form1()
        {
            InitializeComponent();

            //deshabilitamos el boton de calcular hasta que se introduzcan cantidades
            btnCalculate.Enabled = false;

        }


        private void chkType1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkType1.Checked || chkType2.Checked || chkType3.Checked)
            {
                btnCalculate.Enabled = true;
            }
            else
            {
                btnCalculate.Enabled = false;
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {


            //variables subtotales
            double subTotalType1 = 0;
            double subTotalType2 = 0;
            double subTotalType3 = 0;


            //vamos a calcular
            if (QuantityType1.Text == string.Empty)
            {
                QuantityType1.Text = "0";
            }
            if (QuantityType2.Text == string.Empty)
            {
                QuantityType2.Text = "0";
            }
            if (QuantityType3.Text == string.Empty)
            {
                QuantityType3.Text = "0";
            }

            //subtotales conversion
            subTotalType1 = Convert.ToUInt32(QuantityType1.Text) * price1;
            subTotalType2 = Convert.ToUInt32(QuantityType2.Text) * price2;
            subTotalType3 = Convert.ToUInt32(QuantityType3.Text) * price3;


            //Suma de los subtotales
            double TotalGross = subTotalType1 + subTotalType2 + subTotalType3;


            //Shipping
            int num1, num2, num3;

            bool OneType = Int32.TryParse(QuantityType1.Text, out num1);
            bool TwoType = Int32.TryParse(QuantityType2.Text, out num2);
            bool TheeType = Int32.TryParse(QuantityType3.Text, out num3);

            int sum = num1 + num2 + num3;
            double shipping = 0;


            //Impuestos
            double taxes = tax * TotalGross;


            //calcular el total neto
            double totalNet = TotalGross + taxes;


            if (txtOrderNumber.TextLength > 0 && txtCustomerName.TextLength > 0 && txtAdress.TextLength > 0)
            {

                //Informar al cliente del total
                MessageBox.Show($"The total of your purchase is {totalNet:C}", "Resume", MessageBoxButtons.OK, MessageBoxIcon.Information);


                //pedir el pago
                string input = Microsoft.VisualBasic.Interaction.InputBox("Write the payment");
                double payment;
                bool isParsed = double.TryParse(input, out payment);
                if (!isParsed)
                {
                    MessageBox.Show("Please enter a payment ", "Payment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    payment = payment - totalNet;
                }

                //Show Shipping
                if (sum < 20)
                {
                    shipping = 1.50 * (sum);
                    MessageBox.Show($"Your shipping is {shipping:C}", "Shipping", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    shipping = 0;
                    MessageBox.Show($"Your shipping is Free", "Shipping", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }



                //Disccount
                double disccount = 0;

                if (TotalGross >= 500)
                {
                    disccount = (tax + TotalGross) * 0.07;
                    
                    //Show Disccount
                    MessageBox.Show($"7% disccount will be applied", "Discount Offer", MessageBoxButtons.OK, MessageBoxIcon.Information);


                }
                else
                {
                    disccount = 0;
                }


                //Total
                double Total = totalNet + disccount + shipping;


                //Invoice
                label17.Text = $"{subTotalType1:C}";
                label18.Text = $"{subTotalType2:C}";
                label19.Text = $"{subTotalType3:C}";
                label20.Text = $"{TotalGross:C}";
                label21.Text = $"{taxes:C}";
                label22.Text = $"{shipping:C}";
                label23.Text = $"{disccount:C}";
                label24.Text = $"{Total:C}";

            }

            else
            {
                MessageBox.Show("You need to fill these boxes: Order Number, Name, Adress");

                label17.Text = string.Empty;
                label18.Text = string.Empty;
                label19.Text = string.Empty;
                label20.Text = string.Empty;
                label21.Text = string.Empty;
                label22.Text = string.Empty;
                label23.Text = string.Empty;
                label24.Text = string.Empty;
            }

            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Salir de la aplicacion
            Application.Exit();
        }
    }
}

