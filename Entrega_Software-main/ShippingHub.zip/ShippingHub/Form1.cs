namespace ShippingHub
{
    public partial class Form1 : Form
    {
        private List<Package> packagesList; //Lista de paquetes
        private Package objPackage; //Objeto Paquete (paquete con el que se esta trabajando en el momento)
        private int packagePosition; //Posicion de un paquete
        private Random rndNumber; //Generar los Id's de los paquetes
        private int packageNumber; //Number de un paquete

        //lista de los Esstados/States
        string[] state = { "Alabama", "Florida", "Georgia", "Kentucky", "Mississippi", "North Carolina", "South Carolina", "Tennesse", "West Virginia", "Virginia" };


        public Form1()
        {
            InitializeComponent();

            //Desabilitar los botones
            btnBack.Enabled = false;
            btnEdit.Enabled = false;
            btnAdd.Enabled = false;
            btnRemove.Enabled = false;
            btnNext.Enabled = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbState.DataSource = state;
            cmbState.SelectedIndex = 0; //Hacer que al menos el paquete en esa posicion este seleccionado
            packagePosition = 0;
            rndNumber = new Random();
            packageNumber = rndNumber.Next(1, 100000); //Para generar un numero aleatorio para el Id

            groupBox1.Enabled = false;

            //Crear lista de paquete
            packagesList = new List<Package>();

        }

        private void btnScanNew_Click(object sender, EventArgs e)
        {
            //Cada vez que se escanee un paquete:

            //Incrementa el Id
            packageNumber++;
            //Crear un nuevo paquete
            objPackage = new Package(packageNumber);

            //Limpiar los controles
            clearControls();

            //Mostrar el ID del paquete y la fecha de registro
            lblPackageNumber.Text = objPackage.PackageNumber.ToString();
            lblArrivalTime.Text = objPackage.PackageDate.ToString();

            //Permitir al usuario add un paquete
            groupBox1.Enabled = true;
            //habilitar y desabilitar boton de SCAN NEW y ADD
            btnAdd.Enabled = true;
            btnScanNew.Enabled = false;
            setButtons(false);

            //Para que el cursor se vaya directamente a ese textBox
            txtAdress.Focus();
        }

        private void setButtons(bool state)
        {
            btnRemove.Enabled = state;
            btnEdit.Enabled = state;
            btnNext.Enabled = state;
            btnBack.Enabled = state;
            //btnAdd.Enabled = state;

            //Desabilitar los botones de NEXT y BACK si no hay mas paquetes
            if (packagesList.Count < 1)
            {
                btnNext.Enabled = false;
                btnBack.Enabled = false;
            }

            //Si no hay paquetes entonces desabilita los botones de REMOVE y EDIT
            if (packagesList.Count == 0)
            {
                btnRemove.Enabled = false;
                btnEdit.Enabled = false;
            } //if repetido

        }

        private void clearControls()
        {
            txtAdress.Clear();
            txtCity.Clear();
            txtZipCode.Clear();
            cmbState.SelectedText = "";
            lblArrivalTime.Text = "";
            lblPackageNumber.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Asignar los atributos al objeto package
            setPackage();

            //Add paquete a la lista
            packagesList.Add(objPackage);

            //deshabilitar la edicion 
            groupBox1.Enabled = false;

            //habilitar los botones correspondientes
            setButtons(true);

            btnAdd.Enabled = true;

            //Para que los paquetes vayan apareciendo en la lista
            if (cmbViewPackage.Text == cmbState.Text)
            {
                lstPackages.Items.Add(objPackage.PackageNumber);
            }

            cmbViewPackage.Text = objPackage.PackageState;  //Deberia de cambiar el Selected.Index, al estado que fue fue seleccionado
            btnScanNew.Enabled = true;

            clearControls();
        }

        private void setPackage()
        {
            //Tomar todos los datos del objeto paquete y asignarselas
            objPackage.PackageAdress = txtAdress.Text;
            objPackage.PackageCity = txtCity.Text;
            objPackage.PackageState = cmbState.SelectedItem.ToString(); // *. o ** --> ?. ?? una de las dos para evitar que algo nos de nulo
            objPackage.PackageZip = Convert.ToInt32(txtZipCode.Text);
        }

        private void cmbViewPackage_SelectedIndexChanged(object sender, EventArgs e)
        {
            string state = cmbViewPackage.SelectedItem.ToString();

            //limpiar la lista de paquetes
            lstPackages.Items.Clear();

            //Recorrer la lista de paquetes
            foreach (Package package in packagesList)
            {
                //Confirmar que el paquete sea el mismo que en el cmb
                if (package.PackageState == state)
                {
                    //Add ese objeto a la lista
                    lstPackages.Items.Add(package.PackageNumber);
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            //No se puede editar ni la fecha/ID
            if (btnEdit.Text == "EDIT")
            {
                setPackage();

                setButtons(false);

                btnEdit.Enabled = true;
                //Cambia el texto a UPDATE
                btnEdit.Text = "UPDATE";
            }
            else
            {
                setPackage();
                //Se cambia el texto en el cmb para que el elemento se muestre en al estado correspondiente
                cmbViewPackage.Text = objPackage.PackageState.ToString();
                groupBox1.Enabled = false;
                btnEdit.Text = "EDIT";
            }
        }

        private void lstPackages_DoubleClick(object sender, EventArgs e)
        {
            //Para almacenar la informacion del paquete que quiero ver
            string packageData = "";

            if (lstPackages.SelectedIndex != -1)
            {
                foreach (Package item in packagesList)
                {
                    if (item.PackageNumber == Convert.ToInt32(lstPackages.SelectedItem))
                    {
                        //packageData += item.PackageNumber;

                        packageData += "Package" + item.PackageNumber
                                    + "\r\nArrived at " + item.PackageDate.ToString()
                                    + "\r\nAddress: " + item.PackageAdress
                                    + "\r\nCity: " + item.PackageCity
                                    + "\r\nState: " + item.PackageState
                                    + "\r\nZip Code: " + item.PackageZip.ToString("00000");
                    }
                }
            }

            else
            {
                packageData = "Please select a package";

            }

            MessageBox.Show(packageData);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Capturamos el indice del paquete a borrar
            int indexNumber = packagesList.IndexOf(objPackage);
            MessageBox.Show(indexNumber.ToString());


            //Eliminar del listBox el paquete que coincida con el estado visualizado
            if (cmbState.Text == cmbViewPackage.Text)
            {
                lstPackages.Items.Remove(objPackage.PackageNumber);
            }



            //Borramos el elemento de la lista de paquetes
            packagesList.Remove(objPackage);

            //Cargar el siguiente paquete de las lista
            //Preguntar si quedan mas paquetes
            if (packagesList.Count > 0)
            {

                if (packagesList.Count <= indexNumber)
                {
                    objPackage = packagesList[indexNumber - 1];
                    //objPackage = packagesList[indexNumber];


                }

                else
                {
                    objPackage = packagesList[indexNumber];
                }

                //Llamar metodo LoadPackage() que carge un paquete en la lista
                LoadPackage(objPackage);
            }

        }


        private void LoadPackage(Package objPackage)
        {
            //Mostrar el paquete
            txtAdress.Text = objPackage.PackageAdress;
            txtCity.Text = objPackage.PackageCity;
            txtZipCode.Text = objPackage.PackageZip.ToString("0000");
            lblArrivalTime.Text = objPackage.PackageDate.ToString();
            lblPackageNumber.Text = objPackage.PackageNumber.ToString();

        }


        private void btnNext_Click1(object sender, EventArgs e)
        {
        }

        private void btnBack_Click1(object sender, EventArgs e)
        {
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            // Verificar si hay al menos dos paquetes en la lista
            if (packagesList.Count > 0)
            {
                // Incrementar la posici�n del paquete
                packagePosition++;

                // Verificar si llegamos al final de la lista
                if (packagePosition >= packagesList.Count)
                {
                    packagePosition = 0; // Volvemos al inicio si llegamos al final
                }

                // Obtener el paquete en la posici�n actual y cargar sus datos
                objPackage = packagesList[packagePosition];
                LoadPackage(objPackage);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Verificar si hay al menos dos paquetes en la lista
            if (packagesList.Count >= 2)
            {
                // Decrementar la posici�n del paquete
                packagePosition--;

                // Verificar si llegamos al inicio de la lista
                if (packagePosition < 0)
                {
                    packagePosition = packagesList.Count - 1; // Volvemos al final si llegamos al inicio
                }

                // Obtener el paquete en la posici�n actual y cargar sus datos
                objPackage = packagesList[packagePosition];
                LoadPackage(objPackage);
            }
        }
    }
}
