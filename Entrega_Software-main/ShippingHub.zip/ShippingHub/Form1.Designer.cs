﻿namespace ShippingHub
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblArrivalTime = new Label();
            groupBox1 = new GroupBox();
            txtZipCode = new TextBox();
            label6 = new Label();
            cmbState = new ComboBox();
            label5 = new Label();
            txtCity = new TextBox();
            label4 = new Label();
            txtAdress = new TextBox();
            label3 = new Label();
            lblPackageNumber = new Label();
            label2 = new Label();
            btnNext = new Button();
            btnEdit = new Button();
            btnRemove = new Button();
            btnAdd = new Button();
            btnScanNew = new Button();
            btnBack = new Button();
            groupBox2 = new GroupBox();
            lstPackages = new ListBox();
            cmbViewPackage = new ComboBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 25);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 0;
            label1.Text = "Arrived At:";
            // 
            // lblArrivalTime
            // 
            lblArrivalTime.BorderStyle = BorderStyle.Fixed3D;
            lblArrivalTime.Location = new Point(102, 22);
            lblArrivalTime.Margin = new Padding(2, 0, 2, 0);
            lblArrivalTime.Name = "lblArrivalTime";
            lblArrivalTime.Size = new Size(222, 23);
            lblArrivalTime.TabIndex = 1;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtZipCode);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(cmbState);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(txtCity);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtAdress);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(lblPackageNumber);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(21, 65);
            groupBox1.Margin = new Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2);
            groupBox1.Size = new Size(582, 169);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Package Information";
            // 
            // txtZipCode
            // 
            txtZipCode.Location = new Point(458, 122);
            txtZipCode.Margin = new Padding(2);
            txtZipCode.MaxLength = 5;
            txtZipCode.Name = "txtZipCode";
            txtZipCode.Size = new Size(116, 23);
            txtZipCode.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(428, 126);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(27, 15);
            label6.TabIndex = 8;
            label6.Text = "Zip:";
            // 
            // cmbState
            // 
            cmbState.FormattingEnabled = true;
            cmbState.Location = new Point(279, 124);
            cmbState.Margin = new Padding(2);
            cmbState.Name = "cmbState";
            cmbState.Size = new Size(129, 23);
            cmbState.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(234, 129);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(36, 15);
            label5.TabIndex = 6;
            label5.Text = "State:";
            // 
            // txtCity
            // 
            txtCity.Location = new Point(92, 127);
            txtCity.Margin = new Padding(2);
            txtCity.Name = "txtCity";
            txtCity.Size = new Size(116, 23);
            txtCity.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 130);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(31, 15);
            label4.TabIndex = 4;
            label4.Text = "City:";
            // 
            // txtAdress
            // 
            txtAdress.Location = new Point(93, 83);
            txtAdress.Margin = new Padding(2);
            txtAdress.Name = "txtAdress";
            txtAdress.Size = new Size(481, 23);
            txtAdress.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 87);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 2;
            label3.Text = "Adress:";
            // 
            // lblPackageNumber
            // 
            lblPackageNumber.BorderStyle = BorderStyle.Fixed3D;
            lblPackageNumber.Location = new Point(93, 38);
            lblPackageNumber.Margin = new Padding(2, 0, 2, 0);
            lblPackageNumber.Name = "lblPackageNumber";
            lblPackageNumber.Size = new Size(480, 23);
            lblPackageNumber.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 41);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(67, 15);
            label2.TabIndex = 0;
            label2.Text = "Package Id:";
            // 
            // btnNext
            // 
            btnNext.Location = new Point(525, 257);
            btnNext.Margin = new Padding(2);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(78, 20);
            btnNext.TabIndex = 21;
            btnNext.Text = "NEXT>";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(426, 257);
            btnEdit.Margin = new Padding(2);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(78, 20);
            btnEdit.TabIndex = 20;
            btnEdit.Text = "EDIT";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(324, 257);
            btnRemove.Margin = new Padding(2);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(78, 20);
            btnRemove.TabIndex = 19;
            btnRemove.Text = "REMOVE";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(221, 257);
            btnAdd.Margin = new Padding(2);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(78, 20);
            btnAdd.TabIndex = 18;
            btnAdd.Text = "ADD";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnScanNew
            // 
            btnScanNew.Location = new Point(120, 257);
            btnScanNew.Margin = new Padding(2);
            btnScanNew.Name = "btnScanNew";
            btnScanNew.Size = new Size(78, 20);
            btnScanNew.TabIndex = 17;
            btnScanNew.Text = "SCAN NEW";
            btnScanNew.UseVisualStyleBackColor = true;
            btnScanNew.Click += btnScanNew_Click;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(22, 257);
            btnBack.Margin = new Padding(2);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(78, 20);
            btnBack.TabIndex = 16;
            btnBack.Text = "<BACK";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lstPackages);
            groupBox2.Controls.Add(cmbViewPackage);
            groupBox2.Location = new Point(631, 65);
            groupBox2.Margin = new Padding(2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(2);
            groupBox2.Size = new Size(230, 229);
            groupBox2.TabIndex = 22;
            groupBox2.TabStop = false;
            groupBox2.Text = "Packages by State";
            // 
            // lstPackages
            // 
            lstPackages.FormattingEnabled = true;
            lstPackages.ItemHeight = 15;
            lstPackages.Location = new Point(18, 70);
            lstPackages.Margin = new Padding(2);
            lstPackages.Name = "lstPackages";
            lstPackages.Size = new Size(192, 139);
            lstPackages.TabIndex = 1;
            lstPackages.DoubleClick += lstPackages_DoubleClick;
            // 
            // cmbViewPackage
            // 
            cmbViewPackage.FormattingEnabled = true;
            cmbViewPackage.Items.AddRange(new object[] { "Alabama", "Florida", "Georgia", "Kentucky", "Mississippi", "North Carolina", "South Carolina", "Tennesse", "West Virginia", "Virginia" });
            cmbViewPackage.Location = new Point(22, 32);
            cmbViewPackage.Margin = new Padding(2);
            cmbViewPackage.Name = "cmbViewPackage";
            cmbViewPackage.Size = new Size(187, 23);
            cmbViewPackage.TabIndex = 0;
            cmbViewPackage.SelectedIndexChanged += cmbViewPackage_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(889, 318);
            Controls.Add(groupBox2);
            Controls.Add(btnNext);
            Controls.Add(btnEdit);
            Controls.Add(btnRemove);
            Controls.Add(btnAdd);
            Controls.Add(btnScanNew);
            Controls.Add(btnBack);
            Controls.Add(groupBox1);
            Controls.Add(lblArrivalTime);
            Controls.Add(label1);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Shipping Hub App";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblArrivalTime;
        private GroupBox groupBox1;
        private Label label3;
        private Label lblPackageNumber;
        private Label label2;
        private TextBox txtZipCode;
        private Label label6;
        private ComboBox cmbState;
        private Label label5;
        private TextBox txtCity;
        private Label label4;
        private TextBox txtAdress;
        private Button btnNext;
        private Button btnEdit;
        private Button btnRemove;
        private Button btnAdd;
        private Button btnScanNew;
        private Button btnBack;
        private GroupBox groupBox2;
        private ListBox lstPackages;
        private ComboBox cmbViewPackage;
    }
}
