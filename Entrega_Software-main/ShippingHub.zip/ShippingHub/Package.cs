﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShippingHub
{
    internal class Package
    {
        //Atributos del paquete
        private string packageAddress;
        private string packageCity;
        private string packageState;
        private int packageZip;
        private int packageNumber;
        private DateTime packageDate;

        //Propiedades para acceder a los atributos
       public string PackageAdress
       {
            get {return packageAddress;}
            set {packageAddress = value;} 
       }

        public string PackageCity
        { 
            get { return packageCity;}
            set { packageCity = value;}
        }

        public string PackageState
        {
            get { return packageState;}
            set { packageState = value;}
        }
        public int PackageZip
        {
            get { return packageZip;}
            set { packageZip = value;}
        }

        public int PackageNumber
        {
            get { return packageNumber;}
            set { packageNumber = value;}
        }

        public DateTime PackageDate
        {
            get { return packageDate;}
        }


        //constructor
        public Package(int packageNumber)
        {
            this.packageNumber = packageNumber;
            this.packageDate = DateTime.Now;

        }

    }
}
