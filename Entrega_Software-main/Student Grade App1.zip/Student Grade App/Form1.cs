namespace Student_Grade_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //crear las variables que definen las columnas para los nombre y sus promedios
        int campoNombre = 0;
        int campoPromedio = 1;

        //variable que contenga la cantidad de estudiantes que se introducen al programa
        int contadorEstudiantes = 0;

        //Para este ejemplo, asumiremos que el max de estudiantes permitidos es 10

        //Crear un arreglo 10 filas x 2 columnas para almacenar a los estudiantes
        string[,] estudiantes = new string[10, 2];


        //Metodo para calcular el promedio de un estudiante 

        //Modificador-acceso tipo-devuelto nombre-metodo <lista de parametros> --> cuerpo del metodo
        private double CalcularPromedioEstudiante(double test1, double test2, double test3)
        {
            return (test1 + test2 + test3) / 3.0;
        }

        //Metodo para convertir un promedio numerico a letras
        private string ConvertirGradoALetra(double grado)
        {
            if (grado >= 90)
                return "A";
            else if (grado >= 80)
                return "B";
            else if (grado >= 70)
                return "C";
            else
                return "F";
        }

        //Metodo para mostrar el promedio numerico de los estudiantes y de las clase completa
        void MostrarGradosNumericos()
        {
            lstResult.Items.Clear();    //Limpiar listBox

            //creamos una variable auxiliar para calcular el total de los promedios
            double total = 0;

            //iterar sobre el arreglo de estudiantes
            for (int contador = 0; contador < contadorEstudiantes; contador++)
            {
                //mostrar cada estudiantes y su promedio en el lstResult
                lstResult.Items.Add(estudiantes[contador, campoNombre] + "\t" + estudiantes[contador, campoPromedio]);

                //acumular los promedios
                total += Convert.ToDouble(estudiantes[contador, campoPromedio]);
            }

            //Mostrar el promedio de la clase
            txtClassAverage.Text = string.Format("{0:F}", total / contadorEstudiantes);

            //string.Format("{0:F}" , lo que yo quiero convertir a string)
            //El "{0:F}" --> es para ponerlo como un decimal convencional
        }

        //Metodo para mostrar las calificaciones de los estudiantes con letras y el promedio total de la clase como letra
        void MostrarGradosLetras()
        {
            lstResult.Items.Clear();

            //Variable para acumular laos totales de los promedios de los tests
            double total = 0;

            //iteramos sobre el arreglo de estudiantes para mostrarlos en el lstResult y acumular cada promedio

            for (int contador = 0; contador < contadorEstudiantes; contador++)
            {
                //mostrar cada estudiantes y su promedio en el lstResult
                lstResult.Items.Add(estudiantes[contador, campoNombre] + "\t" + ConvertirGradoALetra(Convert.ToDouble(estudiantes[contador, campoPromedio])));

                //acumular el promedio
                total += Double.Parse(estudiantes[contador, campoPromedio]);
            }

            txtClassAverage.Text = string.Format("0:F", ConvertirGradoALetra(total / contadorEstudiantes));
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (txtStudentName.Text == string.Empty)
            {
                errorProvider1.SetError(txtStudentName, "El nombre debe estar lleno");
            }

            //obtener los valores de los campos de entrada
            double test1 = double.Parse(txtTest1.Text);
            double test2 = double.Parse(txtTest2.Text);
            double test3 = double.Parse(txtTest3.Text);

            string studentName = txtStudentName.Text;

            if (contadorEstudiantes < 10)
            { 
                //add el estudiante al arreglo
                estudiantes[contadorEstudiantes, campoNombre] = studentName;
                estudiantes[contadorEstudiantes, campoPromedio] = CalcularPromedioEstudiante(test1, test2, test3).ToString();
                contadorEstudiantes++;
            }
            else 
            {
                btnCalculate.Enabled = false;
            }


            if (radioButton1.Checked)
            {
                MostrarGradosNumericos();
            }
            else if (radioButton2.Checked)
            {
                MostrarGradosLetras();
            }


            //Limpiar los campos de entrada
            txtStudentName.Clear();
            txtTest1.Clear();
            txtTest2.Clear();
            txtTest3.Clear();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            MostrarGradosNumericos();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            MostrarGradosLetras();
        }
    }
}