﻿namespace Student_Grade_App
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnCalculate = new Button();
            groupBox1 = new GroupBox();
            txtTest3 = new TextBox();
            txtTest2 = new TextBox();
            txtTest1 = new TextBox();
            txtStudentName = new TextBox();
            groupBox2 = new GroupBox();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            lstResult = new ListBox();
            label6 = new Label();
            txtClassAverage = new TextBox();
            errorProvider1 = new ErrorProvider(components);
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(51, 51);
            label1.Name = "label1";
            label1.Size = new Size(0, 25);
            label1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(37, 60);
            label2.Name = "label2";
            label2.Size = new Size(170, 30);
            label2.TabIndex = 1;
            label2.Text = "Student's Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(37, 119);
            label3.Name = "label3";
            label3.Size = new Size(74, 30);
            label3.TabIndex = 2;
            label3.Text = "Test 1:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(37, 173);
            label4.Name = "label4";
            label4.Size = new Size(74, 30);
            label4.TabIndex = 3;
            label4.Text = "Test 2:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(37, 222);
            label5.Name = "label5";
            label5.Size = new Size(74, 30);
            label5.TabIndex = 4;
            label5.Text = "Test 3:";
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(260, 314);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(206, 53);
            btnCalculate.TabIndex = 5;
            btnCalculate.Text = "Student Grade";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtTest3);
            groupBox1.Controls.Add(txtTest2);
            groupBox1.Controls.Add(txtTest1);
            groupBox1.Controls.Add(txtStudentName);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(btnCalculate);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Font = new Font("Segoe UI", 11F);
            groupBox1.Location = new Point(33, 28);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(511, 412);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Input Grades";
            // 
            // txtTest3
            // 
            txtTest3.Location = new Point(291, 222);
            txtTest3.Name = "txtTest3";
            txtTest3.Size = new Size(179, 37);
            txtTest3.TabIndex = 9;
            // 
            // txtTest2
            // 
            txtTest2.Location = new Point(291, 166);
            txtTest2.Name = "txtTest2";
            txtTest2.Size = new Size(179, 37);
            txtTest2.TabIndex = 8;
            // 
            // txtTest1
            // 
            txtTest1.Location = new Point(291, 116);
            txtTest1.Name = "txtTest1";
            txtTest1.Size = new Size(179, 37);
            txtTest1.TabIndex = 7;
            // 
            // txtStudentName
            // 
            txtStudentName.Location = new Point(235, 60);
            txtStudentName.Name = "txtStudentName";
            txtStudentName.Size = new Size(235, 37);
            txtStudentName.TabIndex = 6;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButton2);
            groupBox2.Controls.Add(radioButton1);
            groupBox2.Font = new Font("Segoe UI", 11F);
            groupBox2.Location = new Point(33, 470);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(511, 114);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "View";
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Segoe UI", 11F);
            radioButton2.Location = new Point(291, 52);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(94, 34);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Letter";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Segoe UI", 11F);
            radioButton1.Location = new Point(37, 52);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(120, 34);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Numeric";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // lstResult
            // 
            lstResult.FormattingEnabled = true;
            lstResult.ItemHeight = 25;
            lstResult.Location = new Point(572, 41);
            lstResult.Name = "lstResult";
            lstResult.Size = new Size(503, 404);
            lstResult.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(633, 522);
            label6.Name = "label6";
            label6.Size = new Size(153, 30);
            label6.TabIndex = 9;
            label6.Text = "Class Average:";
            // 
            // txtClassAverage
            // 
            txtClassAverage.Location = new Point(807, 519);
            txtClassAverage.Name = "txtClassAverage";
            txtClassAverage.Size = new Size(194, 31);
            txtClassAverage.TabIndex = 10;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1087, 607);
            Controls.Add(txtClassAverage);
            Controls.Add(label6);
            Controls.Add(lstResult);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Student Grade App";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btnCalculate;
        private GroupBox groupBox1;
        private TextBox txtTest3;
        private TextBox txtTest2;
        private TextBox txtTest1;
        private TextBox txtStudentName;
        private GroupBox groupBox2;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private ListBox lstResult;
        private Label label6;
        private TextBox txtClassAverage;
        private ErrorProvider errorProvider1;
    }
}
