﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microonda
{
    public class Time
    {
        public double Horas { get; set; }
        public double Minutos { get; set; }
        public double Segundos { get; set; }

        public Time(int horas, int minutos, int segundos)
        {
            Horas = horas;
            Minutos = minutos;
            Segundos = segundos;
        }
    }
}
