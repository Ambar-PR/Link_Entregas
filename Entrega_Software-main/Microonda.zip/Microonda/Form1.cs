/*
namespace Microonda
{
    public partial class Form1 : Form
    {
        string tiempo = "0";
        public Form1()
        {
            InitializeComponent();
        }

        private void recibirdata(string data)
        {
            string hora, minuto, segundo;
            tiempo = tiempo.ToString().PadLeft(6, '0') + data;
            tiempo = tiempo.Substring(tiempo.Length - 6);

            segundo = tiempo.Substring(4, 2);
            minuto = tiempo.Substring(2, 2);
            hora = tiempo.Substring(0, 2);

            lblTime.Text = string.Format("{0}:{1}:{2}", hora, minuto, segundo);

        }

        private void validardata(string data)
        {
            string hora, minuto, segundo;

            data = data.ToString().PadLeft(6, '0');
            segundo = data.Substring(4, 2);
            minuto = data.Substring(2, 2);
            hora = data.Substring(0, 2);

            if (segundo.CompareTo("59") > 0)
            {
                segundo = "00";
            }

            if (minuto.CompareTo("59") > 0)
            {
                minuto = "00";
            }

            if (hora.CompareTo("09") >= 0)
            {
                hora = "09";
                minuto = "00";
                segundo = "00";
            }

            lblTime.Text = string.Format("{0}:{1}:{2}", hora, minuto, segundo);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            recibirdata("1");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            recibirdata("4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            recibirdata("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            recibirdata("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            recibirdata("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            recibirdata("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            recibirdata("9");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            recibirdata("0");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            recibirdata("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            recibirdata("3");
        }

        private void btnInicio_Click(object sender, EventArgs e)
        {
            validardata(tiempo);
            panel1.BackColor = Color.Cornsilk;

            //System.Windows.Forms.Timer(lblTime.Text);
            timer1.Start();
        }

        private void btnReinicio_Click(object sender, EventArgs e)
        {
            timer1.Stop();

            tiempo = "0";
            validardata(tiempo);
            panel1.BackColor = Color.White;
        }
    }
}
*/


using System;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Microonda
{
    public partial class Form1 : Form
    {
        Time objTime; //= new Time(50, 45, 30);

        string tiempo = "0";

        public Form1()
        {
            InitializeComponent();
        }

        private void recibirdata(string data)
        {
            string hora, minuto, segundo;
            tiempo = tiempo.ToString().PadLeft(6, '0') + data;
            tiempo = tiempo.Substring(tiempo.Length - 6);

            segundo = tiempo.Substring(4, 2);
            minuto = tiempo.Substring(2, 2);
            hora = tiempo.Substring(0, 2);

            lblTime.Text = string.Format("{0}:{1}:{2}", hora, minuto, segundo);
        }

        private void validardata(string data)
        {
            string hora, minuto, segundo;

            data = data.ToString().PadLeft(6, '0');
            segundo = data.Substring(4, 2);
            minuto = data.Substring(2, 2);
            hora = data.Substring(0, 2);

            if (segundo.CompareTo("59") > 0)
            {
                segundo = "00";
            }

            if (minuto.CompareTo("59") > 0)
            {
                minuto = "00";
            }

            if (hora.CompareTo("09") >= 0)
            {
                hora = "09";
                minuto = "00";
                segundo = "00";
            }

            int Hora = Convert.ToInt32(hora);
            int Minuto = Convert.ToInt32(minuto);
            int Segundo = Convert.ToInt32(segundo);

            //Time 
                objTime = new Time(Hora, Minuto, Segundo);

            lblTime.Text = string.Format("{0}:{1}:{2}", hora, minuto, segundo);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            recibirdata("1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            recibirdata("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            recibirdata("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            recibirdata("4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            recibirdata("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            recibirdata("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            recibirdata("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            recibirdata("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            recibirdata("9");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            recibirdata("0");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            {

                Thread.Sleep(500);
                if (objTime.Segundos > 0)
                {
                    //Thread.Sleep((int)TimeSpan.FromSeconds(10).TotalMilliseconds);
                    objTime.Segundos --;
                }
                else if (objTime.Minutos > 0)
                {
                    //Thread.Sleep(1000);
                    objTime.Minutos -= 1;
                    //objTime.Segundos = 59;
                    objTime.Segundos -= 1;

                }
                else if (objTime.Horas > 0)
                {
                    objTime.Segundos = 59;
                    objTime.Minutos = 59;
                    objTime.Horas -= 1;
                }
                //Display al nuevo tiempo;
                //lblTime.Refresh();

                lblTime.Text = $"{objTime.Horas} : {objTime.Minutos} : {objTime.Segundos}";

            }
        }

        private void btnInicio_Click(object sender, EventArgs e)
        {
            validardata(tiempo);
            panel1.BackColor = Color.Cornsilk;
            timer1.Tick += new EventHandler(timer1_Tick);

            timer1.Start();


            //timer1.Enabled = true;

        }

        private void btnReinicio_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            tiempo = "0";
            validardata(tiempo);
            panel1.BackColor = Color.White;
        }

    }
}
